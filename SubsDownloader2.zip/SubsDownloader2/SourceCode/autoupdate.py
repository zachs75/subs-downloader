import urllib2

"""Tutja zrobić trzeba sprawdanie czy ostatnie litery linijek to "/n" jesli tak to trzeba je wycinać"""


newest_version_url = "http://subs-downloader.googlecode.com/svn/current_version.txt"
installed_version = "X:/usr/lib/enigma2/python/Plugins/Extensions/SubsDownloader2/about.nfo"
update_download_dir = "C:/"

req = urllib2.Request(newest_version_url, headers={'Referer' : newest_version_url, 'User-Agent' : 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3)'})
newest_version_file = urllib2.urlopen(req)
newest_version_data = newest_version_file.readlines()
newest_version_file.close()
installed_version_file = open(installed_version,"r")
instaled_version_data = installed_version_file.readline()
installed_version_file.close()
if newest_version_data[0] > instaled_version_data:
    reg2 = urllib2.Request(newest_version_data[1], headers={'Referer' : newest_version_data[1], 'User-Agent' : 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.1.3)'})
    newest_ipk_file = urllib2.FileHandler.urlopen(req2)
    localFile = open(update_download_dir+"subs_downloader_update.ipk", 'w')
    localFile.write(newest_ipk_file.read())
    newest_ipk_file.close()
    localFile.close()
