import threading
import urllib
import os
from Screens.Console import Console
from Screens.Screen import Screen
from Components.MenuList import MenuList
from Components.ActionMap import ActionMap
from enigma import quitMainloop
from Screens.MessageBox import MessageBox

zlib_link = "http://subs-downloader.googlecode.com/files/libzen_0.4.22-0.0_mipsel.ipk"
libmediainfo_link = "http://subs-downloader.googlecode.com/files/libmediainfo_0.7.50-0.0_mipsel.ipk"

class AutoUpdateCheck(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.__latest_version_info_url = "http://subs-downloader.googlecode.com/svn/current_version.txt"
        self.__installed_version_info_file = "/usr/lib/enigma2/python/Plugins/Extensions/SubsDownloader2/about.nfo"
                
    def run(self):
        error_detected = 0
	latest_vestion_data = None
        try:
            current_vestion_data = open(self.__installed_version_info_file, "r")
            current_verion = current_vestion_data.readline()
            current_vestion_data.close()
            print "Current version: %s" % str(current_verion)
        except:
            error_detected = 1        
        try:
            latest_vestion_data = urllib.urlopen(self.__latest_version_info_url)
            latest_verion = latest_vestion_data.readlines()
            latest_vestion_data.close()
            print "Latest version: %s" % str(latest_verion[0])
        #else:
        except:
            #latest_vestion_data.close()
            error_detected = 1
                  
        if error_detected == 1:
            return False
        else:
            if latest_verion[0] > current_verion:
                print "Jest nowa wersja pluginu" 
                return latest_verion[1]
            else:
                print "Posiadasz najnowsza wersje pluginu"
                return False


            
def install_downloadable_content(session, url_to_download):
	installer = "NONE"
	if os.path.isfile("/usr/bin/ipkg") == True:
		installer = "ipkg"
	elif os.path.isfile("/usr/bin/opkg") == True:
		installer = "opkg"
	if installer != "NONE":
	    session.open(Console,_("Installing downloadable contant:"), ["cd /tmp", ("%s install --force-reinstall %s") % (installer, url_to_download)])   
	    return True
	else:
	    return False
            

class PluginIpkUpdate(Screen, AutoUpdateCheck):
	skin = """
		<screen position="150,200" size="460,250" title="New plugin version is avaliable." >
			<widget name="myMenu" position="10,10" size="420,240" scrollbarMode="showOnDemand" />
		</screen>"""
	def __init__(self, session, args = 0):
		self.session = session
		list = []
		self.autoupdate = AutoUpdateCheck()
		list.append((_("Install plugin"), "install"))
		list.append((_("Not now"), "exit"))
		
		Screen.__init__(self, session)
		self["myMenu"] = MenuList(list)
		self["myActionMap"] = ActionMap(["SetupActions"],
		{
			"ok": self.go#,
			#"cancel": self.close(None)
		}, -1)
		self.new_wersion_url = self.autoupdate.run()
		
	def go(self):
		returnValue = self["myMenu"].l.getCurrentSelection()[1]
		if returnValue is not None:
			if returnValue is "install":			    
			    if self.new_wersion_url != False:
				if install_downloadable_content(self.session, self.new_wersion_url) == True:
				    self.restart_message()
				else:
				    self.session.openWithCallback(self.__close_screen__,MessageBox,_("There is problem with ipk installation."), MessageBox.TYPE_INFO)
			    else:
				self.session.openWithCallback(self.__close_screen__,MessageBox,_("There is problem with server connection. \n Please try again later."), MessageBox.TYPE_INFO)
			elif returnValue is "exit":
			    self.__close_screen__()
			    
	def restart_message(self):
	    #self.session.openWithCallback(self.restart_GUI,MessageBox,_("GUI restart is reuired to apply changes. \n\n     Do You want to restart GUI?"), MessageBox.TYPE_YESNO)
	    self.session.openWithCallback(self.restart_GUI,MessageBox,_("GUI restart is reuired to apply changes."), MessageBox.TYPE_INFO)

	def restart_GUI(self, callback = None):
	    """if callback == False:
		self.__close_screen__()
	    if callback == True:
		quitMainloop(3)"""
	    self.__close_screen__()
	                                  
	def __close_screen__(self, callback= None):
	    self.close(None)		
		
		
#def auto_update_callback_Message():
#    print ("Execute")
      
#aa = auto_update_check(auto_update_callback_Message)
#bb = aa.run()

#class fala(auto_update_check):
#    def __init__(self):
#        self.run()