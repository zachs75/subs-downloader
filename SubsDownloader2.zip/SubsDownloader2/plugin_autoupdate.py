import threading
import urllib


class auto_update_check(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.__latest_version_info_url = "http://subs-downloader.googlecode.com/svn/current_version.txt"
        self.__installed_version_info_file = "C:/1!Roboczy/about.nfo"
                
    def run(self):
        error_detected = 0
        try:
        #if os.path.exists(self.__installed_version_info_file) == True:     
            current_vestion_data = open(self.__installed_version_info_file, "r")
            current_verion = current_vestion_data.readline()
            current_vestion_data.close()
            print "Current version: %s" % str(current_verion)
        #else:
        except:
            error_detected = 1
        
        #latest_vestion_data = urllib.urlopen(self.__latest_version_info_url)
        try:
            latest_vestion_data = urllib.urlopen(self.__latest_version_info_url)
        #if latest_vestion_data.getcode() ==200:
            latest_verion = latest_vestion_data.readlines()
            latest_vestion_data.close()
        #else:
        except:
            #latest_vestion_data.close()
            error_detected = 1
                  
        if error_detected == 1:
            return False
        else:
            if latest_verion[0] > current_verion:
                print "Jest nowa wersja pluginu"          
                return latest_verion
            else:
                print "Posiadasz najnowsza wersje pluginu"
                return False

class fala(auto_update_check):
    def __init__(self):
        self.run()
   
      
aa = auto_update_check()
bb = aa.run()

   