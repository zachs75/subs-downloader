pierwsze okno dolna opcja
drugie wszystko wylaczone